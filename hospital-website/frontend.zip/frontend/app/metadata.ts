export const metadata = {
  title: 'City General Hospital',
  description: 'Providing quality healthcare for our community',
} 