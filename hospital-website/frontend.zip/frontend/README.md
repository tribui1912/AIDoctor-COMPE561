To run the project, run the following commands:

```bash
npm install
npm run dev
```

